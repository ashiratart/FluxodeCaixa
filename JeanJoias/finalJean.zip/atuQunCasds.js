function atualizarQuantidadeNoServidor() {
    var productName = prompt("Digite o nome do produto");
    var newQuantity = prompt("Digite a nova quantidade do produto:");

    // Verifique se os campos estão preenchidos
    if (!productName || !newQuantity) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Remova espaços em branco extras dos valores inseridos
    productName = productName.trim();
    newQuantity = newQuantity.trim();

    // Crie um objeto de dados para enviar para o servidor
    var data = {
        productName: productName,
        newQuantity: newQuantity
    };

    // Faça uma solicitação POST para o arquivo PHP
    fetch("update.php", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(function (response) {
        if (response.ok) {
            return response.text();
        } else {
            throw new Error("Erro ao atualizar a quantidade.");
        }
    })
    .then(function (message) {
        alert(message); // Exibe a mensagem de retorno do PHP
        // Faça qualquer ação adicional necessária aqui
    })
    .catch(function (error) {
        alert(error.message);
    });
}

// Chame a função atualizarQuantidadeNoServidor quando desejar atualizar a quantidade no servidor
