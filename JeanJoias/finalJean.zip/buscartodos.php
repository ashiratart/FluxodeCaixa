<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "lojoTest";

// Conexão com o banco de dados
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Consulta SQL
$query = "SELECT nome, codigo, quantidade, preco FROM produtos";
$result = $conn->query($query);

// Montando a lista de resultados
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Produto</th><th>Codigo</><th>Quantidade</th><th>Preço</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["nome"] . "</td><td>" . $row["codigo"] . "</td><td>" . $row["quantidade"] . "</td><td>" . $row["preco"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "Nenhum resultado encontrado.";
}
// Fechando a conexão
$conn->close();
?>