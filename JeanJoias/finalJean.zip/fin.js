function calcularTotal() {
    var tabela = document.getElementById("Ttabela");
    var linhas = tabela.getElementsByTagName("tr");
    var total = 0;

    for (var i = 1; i < linhas.length; i++) {
        var valorCelula = linhas[i].getElementsByTagName("td")[2].textContent.trim();

        if (valorCelula !== "") {
            var valorNumerico = parseFloat(valorCelula.replace("R$", "").replace(".", "").replace(",", "."));
            total += valorNumerico;
        }
    }

    var totalFormatado = "R$" + total.toFixed(2);
    document.getElementById("Tvendashj").value = totalFormatado;
    document.getElementById("totalValue").value = total;
}

function final() {
    calcularTotal(); // Certifique-se de que o valor total esteja atualizado no campo oculto
    
    var valorTotal = document.getElementById("totalValue").value;
    
    fetch("compra.php", {
        method: "POST",
        body: new URLSearchParams({
            totalValue: valorTotal
        })
    })
    .then(response => {
        if (response.ok) {
            alert("Compra processada com sucesso!");
                //liparTabela
                window.location.reload();
        } else {
            console.error("Erro ao processar a compra.");
        }
    })
    .catch(error => {
        console.error("Erro na requisição: " + error);
    });

}


