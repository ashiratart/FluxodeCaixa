<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conecte-se ao banco de dados (substitua com suas credenciais)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lojoTest";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifique a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Obtenha os dados da solicitação POST
$data = json_decode(file_get_contents("php://input"));

$productName = $data->productName;
$newQuantity = $data->newQuantity;

// Atualize a quantidade no banco de dados (substitua com sua consulta SQL)
$sql = "UPDATE produtos SET quantidade = $newQuantity WHERE nome = '$productName'";

if ($conn->query($sql) === TRUE) {
    echo "Quantidade atualizada com sucesso!";
} else {
    echo "Erro ao atualizar a quantidade: " . $conn->error;
}

$conn->close();
?>
