<?php
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["totalValue"])) {
    // Recupere o valor total da compra do POST
    $totalValue = $_POST["totalValue"];
    
    // Obtém a data local atual
    date_default_timezone_set('America/Sao_Paulo'); // Define o fuso horário para o Brasil
    $dataLocal = date("Y-m-d H-i-s"); // Formato: Ano-Mês-Dia 

    // Dados de conexão ao banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lojoTest";

    // Cria uma nova conexão ao banco de dados usando Prepared Statements
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Erro na conexão: " . $conn->connect_error);
    }

    // Prepara a consulta SQL com Prepared Statements
    $sql = "INSERT INTO historicoVendas (datavenda, valor) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sd", $dataLocal, $totalValue); // 's' para string, 'd' para double

    // Executa a consulta preparada
    if ($stmt->execute()) {
        echo "Compra processada com sucesso!";
    } else {
        echo "Erro ao processar a compra: " . $stmt->error;
    }

    // Fecha a conexão
    $stmt->close();
    $conn->close();
} else {
    echo "Erro: Requisição inválida.";
}
?>
