function calcularTotal() {
    var tabela = document.getElementById("Ttabela");
    var linhas = tabela.getElementsByTagName("tr");
    var total = 0;

    for (var i = 1; i < linhas.length; i++) {
        var valorCelula = linhas[i].getElementsByTagName("td")[2].textContent;
        total += parseFloat(valorCelula.replace("R$", ""));
    }

    var totalFormatado = "R$" + total.toFixed(2);
    document.getElementById("Tvendashj").value = totalFormatado; // Atualiza a exibição do total
    document.getElementById("totalValue").value = total; // Atualiza o valor do campo oculto
}

function final() {
        calcularTotal(); // Certifique-se de que o valor total esteja atualizado no campo oculto
    
            // Limpa a tabela mantendo apenas o título
    var tabela = document.getElementById("Ttabela");
    var linhas = tabela.getElementsByTagName("tr");
    for (var i = 1; i < linhas.length; i++) {
        var celulas = linhas[i].getElementsByTagName("td");
        celulas[0].textContent = ""; // Limpa a segunda coluna (índice 1)
        celulas[1].textContent = ""; // Limpa a terceira coluna (índice 2)
        celulas[2].textContent = "";

        var valorTotal = document.getElementById("totalValue").value;
    
        fetch("compra.php", {
            method: "POST",
            body: new URLSearchParams({
                totalValue: valorTotal
            })
        })
        .then(response => {
            if (response.ok) {
                console.log("Compra processada com sucesso!");
                // Redirecionar para a página de sucesso ou realizar outra ação
            } else {
                console.error("Erro ao processar a compra.");
            }
        })
        .catch(error => {
            console.error("Erro na requisição: " + error);
        });
    }

    document.getElementById("Tvendashj").value = "";
}